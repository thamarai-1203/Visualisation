**Tree path to Homo Sapiens**
\mammals->primates->homosapiens


**What is the first common level between us and cats?**

mammals


**What is the distance between the Homo Sapiens and the domestic cat nodes?**
3 levels to mammals 2 levels to filis catus.So it has 5 steps in total