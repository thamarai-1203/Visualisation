### Task 5.1: Correlations
 Scatterplot relates the attributes of "bill_length_mm,bill_depth_mm,flipper_length_mm" which is a <b>positive linear correlation</b>eg. "bill_depth_mm is proportional to bill_length_mm" as they decrease .The parallel coordinates uses polyline to represent all <b>three</b> attributes.


### Task 5.2: Color separation
1. From schemeCategory10 color scale the colors are 
<font color="blue"><b>blue</b></font>
for <b>Aldelie</b>,<font color="orange"><b>orange</b></font> for <b>Chinstrap</b> and <font color="green"><b>green</b></font> for <b>Gentoo</b> and are categorised as "<b>Hue</b>".<br>
2. In flipper_length_mm and in bill_length_mm is <b>small for Adelie</b>,<b>Medium for Chinstrap</b> and <b>LARGE for Gentoo</b>.