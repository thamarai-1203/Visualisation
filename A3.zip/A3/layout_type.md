### Layout type
For Task 1 we implement the Focus+Context Overview layout approach and also in Task 2 we follow the same method.

### The reason
It uses brush function which when one part of data is focused it shows the detailed information which is the context in the other line chart. 